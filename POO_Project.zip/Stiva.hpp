#ifndef Stiva_HPP_INCLUDED
#define Stiva_HPP_INCLUDED

#include "Echipa.hpp"

class Stiva
{
private:
    Echipa *cap;

public:
    Stiva();

    Echipa* get_cap()const;

    void adauga_echipa(Echipa&);
    void afisare_Stiva(ostream&) const;

    void golire_Stiva();
};

#endif // Stiva_HPP_INCLUDED
