#ifndef Echipa_H_INCLUDED
#define Echipa_H_INCLUDED

#include "Player.hpp"

class Echipa
{
private:
    string nume;
    int nrPlayeri;
    Player* playeri;
    float scor;

public:
    Echipa *urmator;

    Echipa();
    Echipa(const Echipa& sursa);

    ~Echipa();

    float get_scor()const;
    string get_nume()const;
    int get_nr()const;
    Player& get_player(int)const;

    void set_scor(float);
    void add_scor();
    void afisare_Echipa(ostream& devo) const;

    Echipa & operator=(const Echipa&);

    friend ifstream& operator>>(ifstream&, Echipa&);
    friend ostream& operator<<(ostream&, Echipa&);
};

#endif // Echipa_H_INCLUDED
