#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED

#include "Echipa.hpp"

class Lista
{
private:

public:
    Echipa ec;
    Lista *urmator;

    Lista();

    void afisare_element(ostream& devo);
    void citeste_element(ifstream&);
    void sterge_el_urm();

    friend ifstream& operator>>(ifstream&, Lista&);

    friend void adaugare_element(Lista*&, ifstream&);
    friend void sterge_el_min(Lista*&, char* inp);
    friend void golire_lista(Lista*&);
};

#endif // LISTA_H_INCLUDED
