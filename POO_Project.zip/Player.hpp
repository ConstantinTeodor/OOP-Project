#ifndef PLAYER_H_INCLUDED
#define PLAYER_H_INCLUDED

#include <iostream>
#include <string>
#include <cstdlib>
#include <fstream>
#include <cstring>
#include <iomanip>

using namespace std;

class Player
{
private:
    string firstName;
    string secondName;
    int points;

public:
    Player(){}
    Player(string, string, int);
    Player(const Player&);

    string get_first() const;
    string get_second() const;
    int get_points() const;

    void set_first(string);
    void set_second(string);
    void set_points(int);

    void add_points();

    friend istream& operator>>(istream&, Player&);
    friend ostream& operator<<(ostream&, Player&);

    Player & operator=(const Player&);
};


#endif // PLAYER_H_INCLUDED
