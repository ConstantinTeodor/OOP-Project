#ifndef AVL_HPP_INCLUDED
#define AVL_HPP_INCLUDED

#include"Lista.hpp"
#include"nod.hpp"

class AVL
{
private:
    node* root;

    node* insert(node*,Echipa&);

    void afisare_AVL(node*, ostream&);

    void golire(node*);

public:
    AVL();
    void golire()
    {
        golire(root);
    }

    int height(node*);

    node* singleRightRotate(node*&);
    node* singleLeftRotate(node*&);
    node* doubleRightRotate(node*&);
    node* doubleLeftRotate(node*&);

    void insert(Echipa& nod)
    {
        root = insert(root, nod);
    }

    void afisare_AVL(ostream& devo)
    {
        afisare_AVL(root, devo);
    }
};

#endif // AVL_HPP_INCLUDED
