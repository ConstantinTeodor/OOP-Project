#include"AVL.hpp"

AVL::AVL()
{
    root = NULL;
}

node* AVL::insert(node* nod,Echipa& e)
{
    if(nod == NULL)
    {
        nod = new node();
        nod->e = e;
        nod->height = 0;
        nod->left = nod->right = NULL;
        return nod;
    }

    if(e.get_scor() < nod->e.get_scor())
        nod->left = insert(nod->left, e);
    else
    if(e.get_scor() > nod->e.get_scor())
        nod->right = insert(nod->right, e);
    else
    if(e.get_nume() < nod->e.get_nume())
        nod->left = insert(nod->left, e);
    else
    if(e.get_nume() > nod->e.get_nume())
        nod->right = insert(nod->right, e);
    else return nod;

    nod->height = max(height(nod->left), height(nod->right))+1;

    int x = height(nod->left) - height(nod->right);

    if(x>1 && ((e.get_scor() < nod->e.get_scor()) || (e.get_scor() == nod->e.get_scor() && e.get_nume() < nod->e.get_nume())))
        return singleRightRotate(nod);
    if(x>1 && ((e.get_scor() >= nod->e.get_scor()) || (e.get_scor() == nod->e.get_scor() && e.get_nume() > nod->e.get_nume())))
        return doubleRightRotate(nod);
    if(x<-1 && ((e.get_scor() > nod->e.get_scor()) || (e.get_scor() == nod->e.get_scor() && e.get_nume() > nod->e.get_nume())))
        return singleLeftRotate(nod);
    if(x<-1 && ((e.get_scor() <= nod->e.get_scor()) || (e.get_scor() == nod->e.get_scor() && e.get_nume() < nod->e.get_nume())))
        return doubleLeftRotate(nod);

    return nod;
}

void AVL::afisare_AVL(node* nod, ostream& devo)
{
    if(nod == NULL)
        return;

    devo << endl << (*(*(*root).right).right).e.get_nume();
    devo << endl << (*(*(*root).right).left).e.get_nume();
    devo << endl << (*(*(*root).left).right).e.get_nume();
    devo << endl << (*(*(*root).left).left).e.get_nume();

}

void AVL::golire(node* t)
{
    if(t == NULL)
        return;
    golire(t->left);
    golire(t->right);
    delete t;
}


int AVL::height(node* nod)
{
    if(nod == NULL)
        return -1;

    else
        return (*nod).height;
}

node* AVL::singleRightRotate(node* &t)
    {
        node* u = t->left;
        t->left = u->right;
        u->right = t;
        t->height = max(height(t->left), height(t->right))+1;
        u->height = max(height(u->left), t->height)+1;
        return u;
    }

node* AVL::singleLeftRotate(node* &t)
    {
        node* u = t->right;
        t->right = u->left;
        u->left = t;
        t->height = max(height(t->left), height(t->right))+1;
        u->height = max(height(t->right), t->height)+1 ;
        return u;
    }

node* AVL::doubleLeftRotate(node* &t)
    {
        t->right = singleRightRotate(t->right);
        return singleLeftRotate(t);
    }

node* AVL::doubleRightRotate(node* &t)
    {
        t->left = singleLeftRotate(t->left);
        return singleRightRotate(t);
    }
