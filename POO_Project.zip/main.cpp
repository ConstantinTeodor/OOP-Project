#include "Coada.hpp"
#include "Stiva.hpp"
#include "BST.hpp"
#include "AVL.hpp"

int main(int argc, char** argv)
{

    Lista *cap = new Lista();

    ifstream cer(argv[1], ios::in);
    //ifstream cer("c.in", ios::in);

    int *cerinta = new int[5];

    for(int i = 0; i < 5; i++)
        cer >> cerinta[i];

    if(cerinta[0] == 1)
    {
        ifstream fin(argv[2], ios::in);
        ofstream fout(argv[3] , ios::out);

        //ifstream fin("d.in", ios::in);
        //ofstream fout("r.out" , ios::out);
        int nrEchipe;
        fin>>nrEchipe;

        cap->citeste_element(fin);

        for(int i = 1; i < nrEchipe; i++)
            adaugare_element(cap, fin);

        Lista *aux;
        aux = cap;

        while(aux != NULL)
        {
            fout << aux->ec.get_nume() << endl;
            aux = aux->urmator;
        }
        fin.close();
        fout.close();
    }

    int nrEchipe = 0;

    if(cerinta[1] == 1)
    {

        ofstream fout2(argv[3], ios::out);
        sterge_el_min(cap, argv[2]);

        //ofstream fout2("r.out", ios::out);
        //sterge_el_min(cap, "d.in");

        Lista* aux = cap;

        while(aux != NULL)
        {
            fout2 << aux->ec.get_nume() << endl;
            aux = aux->urmator;
            nrEchipe++;
        }
        fout2.close();
    }

    Lista *lista;
    if(cerinta[2] == 1)
    {
        ofstream fout3(argv[3], ios::app);
        //ofstream fout3("r.out", ios::app);

        Stiva Winners;
        Stiva Losers;
        int nrRunda = 1;
        while(nrEchipe > 1)
        {
        Lista* aux = cap;
        Coada coada;

        for(int i = 0; i < nrEchipe / 2; i++)
        {
            if(aux != NULL)
            {
                Meci meci(aux->ec, aux->urmator->ec);

                coada.adaugare_meci(meci);
                aux = aux->urmator->urmator;

                Winners.adauga_echipa(meci.setWinner());
                Losers.adauga_echipa(meci.setLoser());
            }
        }
        Echipa* winCap = Winners.get_cap();
        golire_lista(cap);
        Stiva winAux;

        for(int i = 0; i < nrEchipe / 2; i++)
        {
            Echipa* nou = new Echipa(*winCap);
            winAux.adauga_echipa(*nou);
            winCap = winCap->urmator;
            if(nou != NULL)
                delete nou;
        }

        winCap = winAux.get_cap();

        for(int i = 0; i < nrEchipe / 2; i++)
        {
            Lista *nou = new Lista();
            nou->ec = (*winCap);
            nou->urmator = cap;
            winCap = winCap->urmator;
            cap = nou;
        }

        Losers.golire_Stiva();

        fout3 << endl << "--- ROUND NO:"<< nrRunda << endl;
        coada.afisare(fout3);
        fout3 << endl << "WINNERS OF ROUND NO:"<<nrRunda;
        Winners.afisare_Stiva(fout3);
        fout3<<endl;

        if(nrEchipe == 16)
        {
            lista = new Lista(*cap);
            lista->urmator = NULL;

            Lista* aux1 = cap->urmator;

            while(aux1 != NULL)
            {
                Lista *nou = new Lista(*aux1);
                nou->urmator = lista;
                lista = nou;
                aux1 = aux1->urmator;
            }
        }

        Winners.golire_Stiva();

        winAux.golire_Stiva();

        coada.golire_coada();

        nrEchipe = nrEchipe / 2;
        nrRunda++;
        }

        fout3.close();
    }

    if(cerinta[3] == 1)
    {

        ofstream fout4(argv[3], ios::app);
        //ofstream fout4("r.out", ios::app);

        BST arbore1;

        Lista* aux4 = lista;

        while(aux4 != NULL)
        {
            arbore1.insert(aux4->ec);
            aux4 = aux4->urmator;
        }

        fout4 << endl << "TOP 8 TEAMS:";
        arbore1.afisareBST(fout4);

        golire_lista(lista);
        arbore1.copiere(lista);
        arbore1.golire();

        fout4.close();
    }

    if(cerinta[4] == 1)
    {
        ofstream fout5(argv[3], ios::app);
        //ofstream fout5("r.out", ios::app);

        AVL arbore2;
        Lista* aux5 = lista;

        while(aux5 != NULL)
        {
            arbore2.insert(aux5->ec);
            aux5 = aux5->urmator;
        }
        fout5<< endl << "THE LEVEL 2 TEAMS ARE: ";
        arbore2.afisare_AVL(fout5);

        arbore2.golire();
        fout5.close();
    }
    delete [] cerinta;
    golire_lista(cap);
    golire_lista(lista);
    return 0;
}
