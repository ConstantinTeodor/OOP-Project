#include "Echipa.hpp"

Echipa::Echipa()
{
    nume = " ";
    nrPlayeri = 0;
    playeri = NULL;
    scor = 0.0;
    urmator = NULL;
}

Echipa::Echipa(const Echipa& sursa)
{
    nume = sursa.nume;
    nrPlayeri = sursa.nrPlayeri;
    playeri = new Player[nrPlayeri];
    for(int i = 0; i < nrPlayeri; i++)
        playeri[i] = sursa.playeri[i];

    scor = sursa.scor;
    urmator = sursa.urmator;
}

Echipa::~Echipa()
{
    delete [] playeri;
}

float Echipa::get_scor()const
{
    return scor;
}

string Echipa::get_nume()const
{
    return nume;
}

int Echipa::get_nr()const
{
    return nrPlayeri;
}

Player& Echipa::get_player(int i) const
{
    return playeri[i];
}

void Echipa::set_scor(float x)
{
    scor = x;
}

void Echipa::add_scor()
{
    scor = scor + 1.0;
    for(int i=0; i<nrPlayeri; i++)
    {
        playeri[i].add_points();
    }
}

void Echipa::afisare_Echipa(ostream& devo) const
{
    devo << endl << nume;
    for(int i = 0; i < 34 - nume.length(); i++)
        devo << " ";
    devo << "-  " <<fixed<<setprecision(2)<< scor;
}

Echipa& Echipa::operator=(const Echipa& sursa)
{
    nume = sursa.get_nume();
    nrPlayeri = sursa.get_nr();
    if(playeri != NULL)
        delete [] playeri;
    playeri = new Player[nrPlayeri];

    for(int i = 0; i < nrPlayeri; i++)
        playeri[i] = sursa.get_player(i);

    scor = sursa.get_scor();
    urmator = sursa.urmator;

    return *this;
}

ifstream& operator >>(ifstream& devi, Echipa& t)
{
    char* buf = new char[100];

    devi >> t.nrPlayeri;
    devi.getline(buf,256, '\n');

    if(buf[strlen(buf)-1] == ' ')
        buf[strlen(buf)-1] = '\0';

    float sc_aux = 0.0;
    t.nume = &buf[1];

    if(t.playeri != NULL)
        delete [] t.playeri;
    t.playeri = new Player[t.nrPlayeri];
    for(int i = 0; i < t.nrPlayeri; i++)
        devi >> t.playeri[i];


    for(int i = 0; i < t.nrPlayeri; i++)
        sc_aux += t.playeri[i].get_points();

    sc_aux /= t.get_nr();

    t.set_scor(sc_aux);

    delete [] buf;

    return devi;
}

ostream& operator<<(ostream& devo, Echipa& sursa)
{
    devo << sursa.nume << " ";
    devo << sursa.nrPlayeri << " ";

    for(int i = 0; i < sursa.nrPlayeri; i++)
        devo << endl << sursa.playeri[i];

    return devo;

}
