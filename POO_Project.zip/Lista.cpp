#include "Lista.hpp"

Lista::Lista()
{
    ec = Echipa();
    urmator = NULL;
}

void Lista::afisare_element(ostream& devo)
{
    devo << ec;
}

void Lista::citeste_element(ifstream& devi)
{
    devi >> ec;
}

void Lista::sterge_el_urm()
{
    Lista* aux = this->urmator->urmator;
    delete this->urmator;
    this->urmator = aux;
}

ifstream& operator>>(ifstream& devi, Lista& tinta)
{
    devi >> tinta.ec;
    return devi;
}

void adaugare_element(Lista* &cap, ifstream& devi)
{
    Lista *nou = new Lista();
    devi >> nou->ec;

    nou->urmator = cap;
    cap = nou;
}

void sterge_el_min(Lista*& cap, char* inp)
{
    ifstream fin(inp, ios::in);

    int nr_echipe;
    fin >> nr_echipe;

    fin.close();

    Lista *aux = cap;

    int pmax = 1;
    while(nr_echipe >= pmax * 2)
        pmax *= 2;

    float *scoruri = new float[nr_echipe];

    int i = 0;
    while(aux != NULL)
    {
        scoruri[i] = aux->ec.get_scor();
        aux = aux->urmator;
        i++;
    }

    float faux;
    for(int i = 0; i < nr_echipe - 1; i++)
        for(int j = i+1; j < nr_echipe; j++)
            if(scoruri[j] <= scoruri[i])
            {
                faux = scoruri[i];
                scoruri[i] = scoruri[j];
                scoruri[j] = faux;
            }

    for(int i = 0; i < nr_echipe - pmax; i++)
    {
        aux = cap;

        while(aux != NULL)
        {
            if(aux->ec.get_scor() == scoruri[i] && (aux == cap))
            {
                cap = aux->urmator;
                delete aux;
                aux = cap;
                break;
            }
            else if(aux->urmator->ec.get_scor() == scoruri[i])
            {
                aux->sterge_el_urm();
                aux = aux->urmator;
                break;
            }
            else aux = aux->urmator;

        }
    }

    delete [] scoruri;

}

void golire_lista(Lista* &cap)
{
    Lista* aux = cap;
    while(aux != NULL)
    {
        cap = cap->urmator;
        delete aux;
        aux = cap;
    }
}
