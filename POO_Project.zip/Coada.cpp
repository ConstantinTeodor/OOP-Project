#include"Coada.hpp"

Coada::Coada()
{
    m = Meci();
    intrare = NULL;
    iesire = NULL;
}

void Coada::adaugare_meci(Meci &sursa)
{
    if(intrare == NULL)
    {
        intrare = new Meci(sursa);
        intrare->urmator = NULL;
        iesire = intrare;
    }

    else
    {
        Meci *nou = new Meci(sursa);
        intrare->urmator = nou;
        intrare = nou;
        intrare->urmator = NULL;
    }
}

void Coada::eliminare_echipa()
{
    Meci *echipa = new Meci(*iesire);
    iesire = iesire->urmator;
    delete echipa;
}

void Coada::afisare(ostream& devo) const
{
    Meci* aux = iesire;
    while(aux != NULL)
    {
        (*aux).afisare_element(devo);
        aux = (*aux).urmator;
    }
}

void Coada::golire_coada()
{
    Meci* aux = iesire;
    while(aux != NULL)
    {
        iesire = iesire->urmator;
        delete aux;
        aux = iesire;
    }
}

/*ostream & operator<<(ostream& devo, Meci& s)
{
    devo<<s.e1.get_nume();
    for(int i=1; i<=33 - s.e1.get_nume().length(); i++)
    {
        devo<<" ";
    }

    devo<<"-";
    for(int i=1; i<=33-s.e2.get_nume().length(); i++)
    {
        devo<<" ";
    }
    devo<<s.e2.get_nume();
    devo<<endl;

    return devo;
}*/
