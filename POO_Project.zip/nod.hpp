#ifndef NOD_HPP_INCLUDED
#define NOD_HPP_INCLUDED

#include"Lista.hpp"

class node
{
private:

public:
    Echipa e;
    node* left;
    node* right;
    int height;

    node()
{
    left = NULL;
    right = NULL;
    e = Echipa();
    height = 0;
}

    node(Echipa &S)
{
    e = S;
    left = NULL;
    right = NULL;
}

};


#endif // NOD_HPP_INCLUDED
