Constantin Teodor - 321AA - Tema 1

Intregul enunt al temei este implementat (cerinta[n-1] reprezinta 
rezolvarea cerintei n).

Cerinta 1.

Pentru rezolvarea cerintei 1 am creat clasa Player (cpp + hpp),
clasa Echipa (cpp+hpp) si clasa Lista(cpp + hpp).

Clasa Player: folosita pentru stocarea datelor despre playeri, 
nume, prenume si puncte. Am implementat getteri, setteri, constructori
(impliciti, cu parametrii si de copiere), o metoda numita "add_points"
care adauga un punct unui player, si operatorii "=", "<<" si ">>".

Clasa Echipa: folosita pentru crearea echipelor in care se stocheaza
playeri. Am implementat, de asemenea, constructori (implicit si de 
copiere), destructor, getteri, setter pentru scor, o metoda prin care
se adauga un punct echipei (scor = scor + 1.0), dar si fiecarui
player din echipa respectiva, o functie pentru afisarea echipei si 
operatorii "=", "<<" si ">>". 

Operatorii >> sunt optimizati pentru citirea din si in fisierul 
"d.in", conform cerintelor.

Clasa Lista: folosita pentru a crea lista de echipe ce urmeaza a fi
utilizata si in cerintele urmatoare. Elementele din Lista sunt toate
publice. Aceasta contine:
 
--constructorul implicit 

--functii pentru citirea + afisarea unui element 

--o functie pentru stergea elementuluiurmator din lista (aceasta functie este apelata in functia friend
void sterge_el_min )

--functia adaugare_element, utilizata pentru adaugarea din fisier
a unui nou element

--functia stergere_el_min, care are ca scop eliminarea din lista 
a echipelor cu cele mai mici punctaje 

--functia golire_lista care este utilizata pentru eliberarea memoriei
din lista

Cerinta 2.
Pentru rezolvarea cerintei 2, folosesc functia friend sterge_el_min, 
definita in clasa Lista, pentru eliminarea echipelor cu cel mai mic 
punctaj, iar in lista vor ramane nr_echipe = n  (unde n maxim si n 
este putere a lui 2). Apoi declar un auxiliar de tip Lista* pentru
afisarea acesteia in fisier.

Cerinta 3.
Pentru rezolvarea cerintei 3, am fost nevoit sa creez inca 3 clase:

Clasa Meci:
Totul este public. Contine 2 echipe, constructori implicit + cu 
parametrii, 2 metode pentru stabilirea echipei castigatoare si a celei
pierzatoare (metoda pentru stabilirea echipei castigatoare foloseste
functia add_scor(), definita in clasa echipa, pentru adaugarea unui
punct echipei si playerilor din echipa respectiva), functii pentru 
afisarea si citirea unui meci dintr-un fisier si operatorul ">>".

Clasa Coada:
O coada care contine elemente de tip Meci. Sunt implementate in cadrul
acestei cozi constructorul implicit, functie pentru adaugarea unui 
meci, o functie pentru eliminarea unei echipe, o functie de afisare si
o functie pentru golirea cozii.

Clasa Stiva:
Contine elemente de tip echipa. Au fost implementate constructorul
implicit, getter pentru echipa, o functie ce adauga in stiva o
echipa, o functie pentru afisare si o functie pentru golirea stivei.

In main : declar 2 obiecte de tip Stiva (Winners si Losers) in care 
voi memora echipele castigatoare / pierzatoare, creez o copie a
listei de echipe si declar un obiect de tip coada. Creez coada de 
meciuri folosind constructorul cu parametrii din clasa Meci si
functia adauga_echipa din clasa Coada si determin castigatorii si 
pierzatorii fiecarui meci pe parcurs. Creez un auxiliar pentru Winners
pentru a inversa ordinea echipelor din stiva. Sterg lista cu echipe si
o rescriu folosind echipele din stiva de castigatori. Fac afisarea, 
verific daca numarul de echipe = 16 pentru a forma lista cu ultimele 
8 echipe, apoi folosesc functiile de golire de memorie.

Cerinta 4.
Pentru rezolvarea cerintei 4 am creat clasa BST care contine o 
structura numita node, constructor implicit, functie de inserare a 
elementelor in arbore, o functie pentru afisarea arborelui, o functie 
pentru copierea datelor din arbore intr-o lista si o functie pentru 
golirea arborelui.

In main: creez un obiect de tip BST, un auxiliar pentru lista ce 
contine ultimele 8 echipe, folosesc functia insert din clasa BST
pentru adaugarea elementelor in arbore. Am folosit functie afisareBST
pentru scrierea in fisier a echipelor din arbore, am golit lista cu
cele 8 echipe, am folosit functia de copiere din BST pentru a rescrie
lista de echipe ordonata din arbore si functia de golire pentru a 
elibera memoria.


Cerinta 5.
Pentru rezolvarea cerintei 5 am creat o clasa AVL si o clasa nod. Am
deci sa creez clasa nod pentru a incerca si o abordare putin mai 
diferita fata de cerinta 4.

Clasa nod: contine element de tip echipa, nod standa si dreapta si 
height, constructor implicit si contstructor cu parametrii.

Clasa AVL: contine radacina, functie de insert, o functie de afisare,
un getter pentru height, functie pentru golire, si functiile de rotatie.
(singleRightRotate, singleLeftRotate, etc)

In main: declar arborele, declar un nou auxiliar pentru lista de 
echipe, folosesc functia insert intr-un while pentru
a introduce echipele in arbore, folosesc functia de afisare
afisare_AVL, golesc arborele.


La finalul lui main eliberez memoria din lista cu ultimele 8 echipe si
lista de echipe.


------------------------------FEEDBACK -------------------------------

Pozitiv:
Sincer, a fost placut sa lucrez la aceasta tema (mai putin cand vedeam
30 de erori dupa ce modificam vreo 2 3 randuri, dar se rezolvau rapid)
si mi-am imbunatatit abilitatile de a lucra cu stive, cozi si arbori.

Negativ:
Tema mi s-a parut destul de solicitanta, am avut destul de multe 
probleme, dar acest lucru se poate datora si faptului ca nu am prea
lucrat cu stive, cozi, arbori. Timpul de lucru a fost de aproximativ
4 - 5 zile in care m-am axat in mare parte pe POO.

Per total:
Implementarea mea mi se pare eficienta (trebuie sa recunosc ca am mai 
cerut ajutorul si colegilor cand ajungeam in impas), dar cel mai 
probabil mai poate fi optimizata.
