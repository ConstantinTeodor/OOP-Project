#ifndef BTS_HPP_INCLUDED
#define BTS_HPP_INCLUDED

#include"Echipa.hpp"
#include"Lista.hpp"

class BST
{
private:

    struct node
    {
        Echipa e;
        node* left;
        node* right;
    };

    node* root;

    inline node* insert(node* nod, Echipa e)
    {
        if(nod == NULL)
        {
            nod = new node;
            nod->e = e;
            nod->left = nod->right = NULL;
        }
        else if(e.get_scor() < nod->e.get_scor())
                nod->left = insert(nod->left, e);

            else if(e.get_scor() > nod->e.get_scor())
                    nod->right = insert(nod->right, e);
                else if(e.get_nume()>nod->e.get_nume())
                        nod->right = insert(nod->right, e);
                    else nod->left = insert(nod->left, e);

        return nod;
    }

    void afisare_BST(node*, ostream&);

    void copiere(node*, Lista *&);

    void golire(node*);

public:

    BST();

    void insert(Echipa e)
{
    root = insert(root, e);
}

    void afisareBST(ostream& devo)
{
    afisare_BST(root, devo);
    devo << endl;
}

    void copiere(Lista* &destinatie)
    {
        copiere(root, destinatie);
    }

    void golire()
{
    golire(root);
}
};

#endif // BTS_HPP_INCLUDED
