#ifndef Meci_HPP_INCLUDED
#define Meci_HPP_INCLUDED

#include"Lista.hpp"

class Meci
{
public:
    Echipa e1;
    Echipa e2;

    Meci *urmator;

    Meci();
    Meci(Echipa&, Echipa&);


    Echipa& setWinner();
    Echipa& setLoser();

    //friend void adaugare_element(Meci*&, Lista*&);

    void afisare_element(ostream& devo);
    void citire_element(ifstream&);

    friend ifstream& operator>>(ifstream&, Meci&);
};

#endif // Meci_HPP_INCLUDED
