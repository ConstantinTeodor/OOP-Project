#include "Player.hpp"

Player::Player(string x, string y, int z)
{
    firstName = x;
    secondName = y;
    points = z;
}

Player::Player(const Player& player)
{
    firstName = player.firstName;
    secondName = player.secondName;
    points = player.points;
}

string Player::get_first() const
{
    return firstName;
}

string Player::get_second() const
{
    return secondName;
}

int Player::get_points() const
{
    return points;
}

void Player::set_first(string f)
{
    firstName = f;
}

void Player::set_second(string s)
{
    secondName = s;
}
void Player::set_points(int p)
{
    points = p;
}

istream& operator>>(istream& devi, Player& player)
{
    string fn, sn;
    int xp;
    devi >> fn >> sn >> xp;

    player.set_first(fn);
    player.set_second(sn);
    player.set_points(xp);

    return devi;
}

ostream& operator<<(ostream& devo, Player& sursa)
{
    devo << sursa.firstName << " " << sursa.secondName << " " << sursa.points;
    return devo;
}

Player& Player::operator=(const Player& p)
{
    firstName = p.get_first();
    secondName = p.get_second();
    points = p.points;
    return (*this);
}

void Player::add_points()
{
    points ++;
}
