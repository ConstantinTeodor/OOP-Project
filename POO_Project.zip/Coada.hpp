#ifndef COADA_HPP_INCLUDED
#define COADA_HPP_INCLUDED

#include"Meci.hpp"

class Coada
{
private:
    Meci *intrare;
    Meci *iesire;

public:
    Meci m;

    Coada();

    void adaugare_meci(Meci &);
    void eliminare_echipa();

    void afisare(ostream&)const;

    void golire_coada();

    friend ostream & operator<<(ostream&, Meci&);
};

#endif // COADA_HPP_INCLUDED
