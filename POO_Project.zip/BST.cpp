#include"BST.hpp"

BST::BST()
{
    root = NULL;
}

void BST::afisare_BST(node *nod, ostream &devo)
{
    if(nod)
    {
        afisare_BST(nod->right, devo);
        nod->e.afisare_Echipa(devo);
        afisare_BST(nod->left, devo);
    }
}

void BST::copiere(node *nod, Lista* &destinatie)
{
    if(nod == NULL)
        return;
    copiere(nod->right, destinatie);
    Lista *element = new Lista();
    element->ec = nod->e;
    element->urmator = NULL;
    if(destinatie == NULL)
        destinatie = element;
    else
    {
        Lista *nod = destinatie;
        while(nod->urmator != NULL)
            nod = nod->urmator;
        nod->urmator = element;
    }
    //delete element;
    copiere(nod->left, destinatie);
}

void BST::golire(node* t)
{
    if(t == NULL)
        return;
    golire(t->left);
    golire(t->right);
    delete t;
}
