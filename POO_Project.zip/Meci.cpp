#include"Meci.hpp"

Meci::Meci()
{
    e1 = Echipa();
    e2 = Echipa();
    urmator = NULL;
}

Meci::Meci(Echipa& ec1, Echipa& ec2)
{
    e1 = ec1;
    e2 = ec2;
}

Echipa& Meci::setWinner()
{
    if(e1.get_scor()>e2.get_scor())
        {
            e1.add_scor();
            return e1;
        }
    else
    {
        e2.add_scor();
        return e2;
    }
}

Echipa& Meci::setLoser()
{
    if(e1.get_scor()<=e2.get_scor())
        return e1;
    else return e2;
}

void Meci::citire_element(ifstream& devi)
{
    devi >> e1 >> e2;
}

void Meci::afisare_element(ostream& devo)
{
    devo << e1.get_nume();
    for(int i = 0; i < (33 - e1.get_nume().length()); i++)
        devo << " ";

    devo << "-";

    for(int i = 0; i < (33 - e2.get_nume().length()); i++)
        devo << " ";

    devo << e2.get_nume() << endl;
}

ifstream& operator>>(ifstream& devi, Meci& meci)
{
    devi >> meci.e1 >> meci.e2;
    return devi;
}
