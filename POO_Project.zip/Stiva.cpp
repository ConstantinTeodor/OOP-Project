#include "Stiva.hpp"

Stiva::Stiva()
{
    cap = NULL;
}

Echipa* Stiva::get_cap()const
{
    return cap;
}

void Stiva::adauga_echipa(Echipa& sursa)
{
    if(cap == NULL)
    {
        cap = new Echipa(sursa);
        cap->urmator = NULL;
    }

    else
    {
        Echipa* nou = new Echipa(sursa);
        nou->urmator = cap;
        cap = nou;
    }
}

void Stiva::afisare_Stiva(ostream& devo) const
{
    Echipa* aux = cap;
    while(aux != NULL)
    {
        aux->afisare_Echipa(devo);
        aux = aux->urmator;
    }
}

void Stiva::golire_Stiva()
{
    Echipa* aux = cap;
    while(aux != NULL)
    {
        cap = cap->urmator;
        delete aux;
        aux = cap;
    }
}
